.. role:: hidden
    :class: hidden-section

torchtext.data.utils
===========================

.. automodule:: torchtext.data.utils
.. currentmodule:: torchtext.data.utils

:hidden:`get_tokenizer`
~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: get_tokenizer 

:hidden:`ngrams_iterator`
~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: ngrams_iterator 
