.. role:: hidden
    :class: hidden-section

torchtext.utils
===========================

.. automodule:: torchtext.utils
.. currentmodule:: torchtext.utils

:hidden:`reporthook`
~~~~~~~~~~~~~~~~~~~~

.. autofunction:: reporthook

:hidden:`download_from_url`
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: download_from_url

:hidden:`unicode_csv_reader`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: unicode_csv_reader 

:hidden:`extract_archive`
~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: extract_archive
