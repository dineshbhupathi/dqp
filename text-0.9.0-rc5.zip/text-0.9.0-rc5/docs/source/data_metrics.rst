.. role:: hidden
    :class: hidden-section

torchtext.data.metrics
===========================

.. automodule:: torchtext.data.metrics
.. currentmodule:: torchtext.data.metrics

:hidden:`bleu_score`
~~~~~~~~~~~~~~~~~~~~

.. autofunction:: bleu_score
