from .utils import count_model_param

__all__ = ["count_model_param"]
