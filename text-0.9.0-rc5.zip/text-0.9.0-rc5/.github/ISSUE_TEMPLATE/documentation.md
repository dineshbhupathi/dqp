---
name: "\U0001F4DA Documentation"
about: Report an issue related to TorchText

---

## 📚 Documentation

**Description**
<!-- A clear and concise description of what content in https://torchtext.readthedocs.io/en/latest/ is an issue. -->
